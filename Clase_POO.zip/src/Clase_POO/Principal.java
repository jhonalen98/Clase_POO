package Clase_POO;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Pelicula objPelicula= new Pelicula();
		objPelicula.titulo="Juego de calamar";
		objPelicula.director="Hwang Dong-hyuk";
		objPelicula.genero="Terror";
		objPelicula.anioLanzamiento=2021;
		objPelicula.horasduracion=20;
		objPelicula.paisOrigen="Corea del sur";
		objPelicula.idiomaOriginal="Coreano";
		objPelicula.calificacionIMDb=8.00;
		objPelicula.calificacionRottenTomatoes=90.00;
		objPelicula.presupuesto=21400000;
		objPelicula.recaudacion=900000000;
		objPelicula.productora="Netflix";
		objPelicula.guionista="Hwang Dong-hyuk";
		objPelicula.esBasadaEnLibro=false;
		objPelicula.protagonista="Seong Gi-hun";
		objPelicula.antagonista="Hwang In-ho";
		objPelicula.bandaSonora="Jung Jae-il";
		objPelicula.distribuidora="Netflix";
		objPelicula.clasificacionPorEdad="Mayores de 16 años";
		objPelicula.esParteDeUnaSaga=false;
		
	}

}
