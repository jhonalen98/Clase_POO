package Clase_POO;

public class Pelicula {

	public String titulo;
	public String director;
	public String genero;
	public int anioLanzamiento;
	public int horasduracion;
	public String paisOrigen;
	public String idiomaOriginal;
	public double calificacionIMDb;
	public double calificacionRottenTomatoes;
	public int presupuesto;
	public int recaudacion;
	public String productora;
	public String guionista;
	public boolean esBasadaEnLibro;
	public String protagonista;
	public String antagonista;
	public String bandaSonora;
	public String distribuidora;
	public String clasificacionPorEdad;
	public boolean esParteDeUnaSaga;
}
